1. Open Command Prompt
2. Set the directory to where the PeldorFit executable is saved:
    cd ...\PeldorFit\Windows
3. Set the path to the config file and run the program:
    peldorfit.exe "Examples\bisnitroxide_config.cfg"
4. The program will output the progress to the Command Prompt
   and will save fitting results into the "Examples\Results\" folder.